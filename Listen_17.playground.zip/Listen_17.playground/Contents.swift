import UIKit

let array = ["a", "b", "c"]

array[0]
array[1]
array[2]



struct Family {
    var father = "Father"
    var mother = "Mother"
    var kids = ["Kid1", "Kid2", "Kid3"]
    
    var count: Int {
        return 2 + array.count
    }
    
    subscript(index: Int) -> String? {
        get {
            switch index {
            case 0: return father
            case 1: return mother
            case 2..<(2 + array.count): return kids[index - 2]
            default: return nil
            }
        }
        set {
            let value = newValue ?? ""
            switch index {
            case 0: return father = value
            case 1: return mother = value
            case 2..<(2 + array.count): return kids[index - 2] = value
            default: break
        }
    }
}
    
    subscript(index: Int, suffix: String) -> String? {
        var name = self[index] ?? ""
        name += " " + suffix
        return name
    }

}

var family = Family()
family.father
family.mother
family.kids[0]

family.count


family[0]
family[1]
family[2]


family[0] = "Daddy"
family.father

family.kids[1] = "Buddy"
family[3] = "Bob"
family.kids[1]

family[3, "the great"]



struct Field {
    var dict = [String: String]()
    
    subscript(column: String, row: Int) -> String? {
        get {
            return dict[column + String(row)]
        }
        set {
            dict[column + String(row)] = newValue
        }
    }
}


var field = Field()

field["a", 5]
field["a", 5] = "X"
field["a", 5]





struct TimesTable {
    let multiplayer: Int
    
    subscript(index: Int) -> Int {
        return multiplayer * index
    }
}

var primer1 = TimesTable(multiplayer: 5)
primer1[5]
primer1




enum Planet: Int {
    case mercury = 1, venus, earth, mars, jupiter, saturn, uranus, neptune
    static subscript(n: Int) -> Planet {
        return Planet(rawValue: n)!
    }
}
let mars = Planet[4]
print(mars)




// HomeTask 17.1






enum FieldType: Character {
    case o = "⭕"
    case x = "❌"
    case empty = "⬜"
}

class TicTacToe {
    let size: Int
    var array: [[FieldType]] = [[FieldType]]()
    init(size: Int) {
        self.size = size
        create()
    }
    func create() {
        print("Create new Tic Tac Toe")
        array = [[FieldType]]()
        for _ in 0..<size {
            let line = Array(repeating: FieldType.empty, count: size)
            array.append(line)
        }
    }
    func show() {
        for line in array {
            var lineString = ""
            for character in line {
                lineString += String(character.rawValue)
            }
            print(lineString)
        }
    }
    subscript (x: Int, y: Int) -> FieldType {
        get {
            if x < 0 || y < 0 || x >= size || y >= size {
                return .empty
            }
            return array[y][x]
        }
        set {
            print("\(newValue.rawValue) - (\(x), \(y))")
            if !(x < 0 || y < 0 || x >= size || y >= size || newValue == .empty || array[y][x] != .empty) {
                array[y][x] = newValue
            }
        }
    }
}

let ticTacToe = TicTacToe(size: 3)
ticTacToe.show()
ticTacToe[0,2] = .x
ticTacToe.show()
ticTacToe[1,1] = .o
ticTacToe.show()
ticTacToe[1,2] = .x
ticTacToe.show()
ticTacToe[2,0] = .o
ticTacToe.show()
ticTacToe[2,2] = .x
ticTacToe.show()
ticTacToe.create()
ticTacToe.show()















/*

enum Color: String {
    case White = "White"
    case Black = "Black"
}

struct ChessBoard {
    var x: Int {
        didSet {
            if x < 1 || x > 8 {
                x = oldValue
            }
        }
    }
    var y: String
    
    var point = [Int: String]()

    
    subscript(x: Int, y: String) -> String? {
        get {
            return
        }
        set {
            
        }
    }
}

*/
