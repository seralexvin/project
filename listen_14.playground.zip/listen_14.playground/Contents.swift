import UIKit
import Foundation

/*
struct Student {
    var firstName : String {
        
        willSet(newFirstName) {
            print("will set " + newFirstName + " instead of " + firstName)
        }
        
        didSet(oldFirstName) {
            print("did set " + firstName + " instead of " + oldFirstName)

            firstName = firstName.capitalized
        }
    }
    
    var lastName: String {
        
    didSet {
        lastName = lastName.capitalized
    }
    }
    
    var fullName: String {
        
        get {
            return firstName + " " + lastName
        }
        set {
            print("fullName wants to be set to " + newValue)
            
            let words = newValue.components(separatedBy: " ")
            
            if words.count > 0 {
                firstName = words[0]
            }
            
            if words.count > 1 {
                lastName = words[1]
            }
        }
    }
}



var student = Student(firstName: "Alex", lastName: "Skutarenko")

student.firstName
student.lastName
student.fullName


student.firstName = "Bob"
student.firstName
student.lastName
student.fullName

student.fullName = "IVAn ivAnOv"
student.firstName
student.lastName
student.fullName

*/


// task 14.1

struct Student2 {
    
    var firstName: String {
        willSet {
            print("wil set " + newValue + " instead of " + firstName)
        }
        
        didSet {
            print("did set " + firstName + " instead of " + oldValue)
            
            firstName = firstName.capitalized
        }
    }
    var lastName: String {
        
        didSet {
            lastName = lastName.capitalized
        }
    }
    var fullName: String {

        get {
            return firstName + " " + lastName
        }

        set {
            print("ful name wants to be set to " + newValue)
            
            let words = newValue.components(separatedBy: " ")
            if words.count > 0 {
                firstName = words[0]
            }
            
            if words.count > 1 {
                lastName = words[1]
            }
        }
    }
}

var student2 = Student2(firstName: "Alexei", lastName: "Durnev")
student2.firstName
student2.lastName
student2.fullName

student2.firstName = "bob"
student2.lastName = "English"

student2.firstName
student2.lastName
student2.fullName = "Senior Mafio"

student2.firstName
student2.lastName
student2.fullName




// HOMETASK task 14.2
/*
var curDate = (day: 13, months: 11, year: 2021)


struct Student3 {
    
    var day: Int
    var month: Int
    var year: Int
    var name: String {
        
        didSet {
            name = name.capitalized
        }
    }
    var surName: String {
        
        didSet {
            name = name.capitalized
        }
    }
    var age: Int {
        
        get {
            if month <= curDate.months && day <= curDate.day {
                return curDate.year - year
            } else {
                return (curDate.year - year) - 1
            }
        }
    }
    
    var calcYearStudy: Int {
        
        get {
            if age < 6 {
                return 0
            } else {
                return age - 6
            }
        }
    }
}

var student3 = Student3(day: 26, month: 8, year: 1993, name: "Servin", surName: "Asanov")
print(student3)

student3.age
student3.calcYearStudy
*/

//

var curDate = (day: 13, month: 11, year: 2021)

struct Student4 {
    
    var day: Int
    var month: Int
    var year: Int
    var age: Int {
        
        get {
            if curDate.month >= month && curDate.day <= day {
            return curDate.year - year
        } else {
            return (curDate.year - year) - 1
        }
        }
    }
    
    var calcStudy: Int {
        
        get {
            if age < 6 {
                return 0
            } else {
                return age - 6
            }
        }
    }
}

var student4 = Student4(day: 13, month: 11, year: 1993)
student4.age
student4.calcStudy


//

struct Section {
    
    struct Point{
        var x: Double
        var y: Double
    }
    
    var pointA: Point
    var pointB: Point
    
    var midPoint: Point {
        
        get {
            return Section.Point(x: ((pointA.x + pointB.x) / 2), y: (pointA.y + pointB.y) / 2)
        }
        
        set {
            pointA.x = (newValue.x - midPoint.x) + pointA.x
            pointA.y = (newValue.y - midPoint.y) + pointA.y
            
            pointB.x = (newValue.x - midPoint.x) + pointB.x
            pointB.y = (newValue.y - midPoint.y) + pointB.y
        }
    }
    
    var lenght: Double {
        get {
            return pow(pointB.x - pointA.x, 2) + pow(pointB.y - pointA.y, 2).squareRoot()
        }
        
        set {
            let a = ((pointA.x * (lenght - newValue)) + (pointB.x * newValue)) / lenght
            let b = ((pointA.y * (lenght - newValue)) + (pointB.y * newValue)) / lenght
            
            pointB.x = a
            pointB.y = b
        }
    }
}

var point1 = Section(pointA: Section.Point(x: 20.0, y: 20.0), pointB: Section.Point(x: 10.0, y: 10.0))
point1.midPoint = Section.Point(x: 5.0, y: 5.0)

point1.lenght
point1.pointA
point1.pointB


point1.lenght = 20
point1.pointA
point1.pointB
