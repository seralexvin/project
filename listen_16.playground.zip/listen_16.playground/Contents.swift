import UIKit
import Foundation
import Darwin

/*

struct Point {
    var x : Int
    var y : Int
    
//    mutating func moovebyX(x: Int, andY y: Int) {
//        self.x += x
//        self.y += y
//    }
    
    mutating func mooveByx(x: Int, andy y : Int) {
        self = Point(x: self.x + x, y: self.y + y)
    }
}


// primer self
enum Color {
    
    static func numberOfElements() -> Int {
        return 2
    }
    
    case White
    case Black
    
    mutating func invert() {
        if self == .White {
            self = .Black
        } else {
            self = .White
        }
    //self = self == .White ? .Black : .White // ILI TAK
    }
}


var c = Color.White
c
c.invert()
c

Color.numberOfElements()



func move(point: Point, byX: Int, andY: Int) -> Point {
    
    
    return point
}

var p = Point(x: 1, y: 1)
p.mooveByx(x: 2, andy: 2)


*/




// HOMETASK 16.1

let DogChar = "\u{1f436}"
let BoxChar = "\u{1f3e1}"
let BoneChar = "\u{1f357}"
var FieldChar = "\u{1F532}"
let Finish = "\u{1F3C1}"


let sizeRoom = (h: 10, w: 10)

struct Dog {
    var x: Int {
        didSet {
            if x < 1 || x > sizeRoom.w {
                x = oldValue
            }
        }
    }
    
    var y: Int {
        didSet {
            if y < 1 || y > sizeRoom.h {
                y = oldValue
            }
        }
    }
}


struct Box {
    var x: Int {
        didSet {
            if x < 1 || x > sizeRoom.w {
                x = oldValue
            }
        }
    }
    
    var y: Int {
        didSet {
            if y < 1 || y > sizeRoom.h {
                y = oldValue
            }
        }
    }
}


struct Bone {
    var x: Int {
        didSet {
            if x < 1 || x > sizeRoom.w {
                x = oldValue
            }
        }
    }
    
    var y: Int {
        didSet {
            if y < 1 || y > sizeRoom.h {
                y = oldValue
            }
        }
    }
}


struct Room {
    var width: Int {
        didSet {
            if width < 2 || width > sizeRoom.w {
                width = oldValue
            }
        }
    }
    var hidth: Int {
        didSet {
            if hidth < 2 || hidth > sizeRoom.h {
                hidth = oldValue
            }
        }
    }
}

enum Position {
    case up
    case down
    case right
    case left
}


struct Game {
    var dog: Dog
    var box: Box
    var bone: Bone
    var room: Room
    
    func winGame() {
        if bone.x == box.x && bone.y == box.y {
            print("YOU WIN - dog in box")
            FieldChar = Finish
        }
    }
    
        
    mutating func Moving(move: Position) {
        switch move {
            case .up:
                dog.y += 1
                if dog.y == bone.y && dog.x == bone.x {
                    bone.y += 1
                    winGame()
                }
            case .down:
                dog.y -= 1
                if dog.y == bone.y && dog.x == bone.x {
                    bone.y -= 1
                    winGame()
                }
            case .right:
                dog.x += 1
                if dog.x == bone.x && dog.y == bone.y {
                    bone.x += 1
                    winGame()
                }
            case .left:
                dog.x -= 1
                if dog.x == bone.x && dog.y == bone.y {
                    bone.x -= 1
                    winGame()
                }
            }
        }
    
    func printField() {
        
        for i in (1...room.hidth).reversed() {
            for j in (1...room.width) {
                var str = String()
                switch (i,j) {
                    case(dog.y, dog.x): str = DogChar
                    case(box.y, box.x): str = BoxChar
                    case(bone.y, bone.x): str = BoneChar
                    default: str = FieldChar
                }
                print(str, terminator: "")
            }
            print("\n", terminator: "")
        }
        print()
    }
}


var game = Game(dog: Dog(x: 4, y: 4), box: Box(x: 9, y: 9), bone: Bone(x: 6, y: 6), room: Room(width: 10, hidth: 20))

game.printField()

game.Moving(move: .right)
game.printField()

game.Moving(move: .up)
game.printField()

game.Moving(move: .up)
game.printField()

game.Moving(move: .right)
game.printField()

game.Moving(move: .right)
game.printField()

game.Moving(move: .right)
game.printField()

game.Moving(move: .down)
game.printField()

game.Moving(move: .right)
game.printField()

game.Moving(move: .up)
game.printField()

game.Moving(move: .up)
game.printField()

game.Moving(move: .up)
game.printField()
