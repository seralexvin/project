import UIKit
import Foundation

let MaxNameLenght = 10

class Human {
    
    var name: String {
        didSet {
            if name.count > MaxNameLenght {
                name = oldValue
            }
        }
    }
    
    lazy var storyOfMyLife = "This is story of my entire life ..."
    
    class var maxAge: Int {
        return 100
    }
    
    var age: Int {
        didSet {
            if age > Human.maxAge {
                age = oldValue
            }
        }
    }
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}


struct Cat {
    
    var name: String {
        didSet {
            if name.count > MaxNameLenght {
                name = oldValue
            }
        }
    }
    static let maxAge = 20
    
    static var totalCats = 0
    
    var age: Int {
        didSet {
            if age > Cat.maxAge {
                age = oldValue
            }
        }
    }
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
        Cat.totalCats += 1
    }
}



enum Direction {
    
    static let enumDescreiption = "Directions in the game"
    case Left
    case Right
    case Top
    case Bottom
    
    var isVertical : Bool {
        return self == .Top || self == .Bottom
    }
    
    var isHorizontal : Bool {
        return !isVertical
    }
}

Direction.enumDescreiption

let d = Direction.Right
d.isVertical
d.isHorizontal




let human = Human(name: "Peter", age: 40)
human
human.storyOfMyLife
human

var cat = Cat(name: "Whiten", age: 10)
var cat2 = Cat(name: "Whiten", age: 10)
var cat3 = Cat(name: "Whiten", age: 10)
var cat4 = Cat(name: "Whiten", age: 10)


human.age = 1000
cat.age = 50

cat.name = "aslkfn"
cat.name

human.age
cat.age

Cat.totalCats




// home Task 15.1

enum FileType {
    
    case visible
    case hidden
}

struct FileDescription {
    
    static var maxSize = 3_000_000_000
    
    var path: String {
        return pathFolder + fileName
    }
    
    var fileSize: Int {
        didSet {
            if fileSize > FileDescription.maxSize {
                fileSize = oldValue
            }
        }
    }
    
    var fileName: String
    var pathFolder: String
    var typeOfFile: FileType
    var contentFile: String
}


var file = FileDescription(fileSize: 10000, fileName: "test file", pathFolder: "c:\\", typeOfFile: .visible, contentFile: "Content")
print(file.path)

print(file.fileSize)




// task 15.2

enum ColorGamma: Int {
    
    static var countColor = 3
    static var firstColor = ColorGamma.red
    static var lastColor = ColorGamma.blue
    
    case red = 0xFF0000
    case blue = 0x00FF00
}

ColorGamma.firstColor
ColorGamma.lastColor




// task 15.3

let MinAge = 18
let MaxAge = 45

let MinLengNameSur = 4
let MaxLengNameSur = 8

let MinHeight = 165.0
let MaxHeight = 190.0

let MinWeight = 45.0
let MaxWeight = 100.0

class MyHyman {
    
    var name: String {
        didSet {
            if name.count < MinLengNameSur || name.count > MaxLengNameSur {
                name = oldValue
            }
        }
    }
    
    var surname: String {
        didSet {
            if surname.count < MinLengNameSur || surname.count > MaxLengNameSur {
                surname = oldValue
            }
        }
    }
    
    var age: Int {
        didSet {
            if age < MinAge || age > MaxAge {
                age = oldValue
            }
        }
    }
    
    var height: Double {
        didSet {
            if height < MinHeight || height > MaxHeight {
                height = oldValue
            }
        }
    }
    
    var weight: Double {
        didSet {
            if weight < MinWeight || weight > MaxWeight {
                weight = oldValue
            }
        }
    }
    
    static var counterHuman = 0
    
    
    init(name: String, surname: String, age: Int, height: Double, weight: Double) {
        self.name = name
        self.surname = surname
        self.age = age
        self.height = height
        self.weight = weight
        
        MyHyman.counterHuman += 1
    }
}

var human1 = MyHyman(name: "Servin", surname: "Asanov", age: 28, height: 183.0, weight: 70.0)
MyHyman.counterHuman

var human2 = MyHyman(name: "Edie", surname: "Asanova", age: 25, height: 167.0, weight: 54.0)
MyHyman.counterHuman

human1.age = 50
human1.age

human1.name = "Ser"
human1.name

human2.surname = "Ametova-Asanova"
human2.surname

human1.weight = 105
human1.weight

human2.weight = 45
human2.weight

human1.height = 210
human1.height
