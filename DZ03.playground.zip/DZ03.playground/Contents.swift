//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

// 1
var sportResult = (maxOtzhimaniya: 20, maxPodtyagivaniya: 10, maxPrisedaniya: 40)
print(sportResult)

// 2
print(sportResult.0)
print(sportResult.1)
print(sportResult.2)

print(sportResult.maxOtzhimaniya)
print(sportResult.maxPodtyagivaniya)
print(sportResult.maxPrisedaniya)

// 3
let sportResultWife = (maxOtzhimaniya: 5, maxPodtyagivaniya: 2, maxPrisedaniya: 50)
print(sportResultWife.0)
print(sportResultWife.1)
print(sportResultWife.2)

/*
 var changeParametr = sportResultWife
sportResult = changeParametr
sportResult
*/

// 4
var sportResultDifference = (sportResult.0 - sportResultWife.0, sportResult.1 - sportResultWife.1, sportResult.2 - sportResultWife.2)
print(sportResultDifference)
