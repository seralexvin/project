import UIKit

var Grass = "\u{1F7E2}"
var Firework = "\u{1F386}"
let FootBall = "\u{26BD}"
let FootGates = "\u{1F945}"
let FootPlayer = "\u{1F9D4}"


struct Field {
    
    static var maxWidth = 6
    static var maxHeigth = 6
    
    var width: Int {
        didSet {
            if width < 1 || width > Field.maxWidth {
                width = oldValue
            }
        }
    }
    
    var heigth: Int {
        didSet {
            if heigth < 1 || heigth > Field.maxHeigth {
                heigth = oldValue
            }
        }
    }
}


struct Gates {
    var x: Int {
        didSet {
            if x < 1 || x > Field.maxWidth {
                x = oldValue
            }
        }
    }
    
    var y: Int {
        didSet {
            if y < 1 || y > Field.maxHeigth {
                y = oldValue
            }
        }
    }
}


struct Ball {
    var x: Int {
        didSet {
            if x < 1 || x > Field.maxWidth {
                x = oldValue
            }
        }
    }
    
    var y: Int {
        didSet {
            if y < 1 || y > Field.maxHeigth {
                y = oldValue
            }
        }
    }
}


struct Player {
    var x: Int {
        didSet {
            if x < 1 || x > Field.maxWidth {
                x = oldValue
            }
        }
    }
    
    var y: Int {
        didSet {
            if x < 1 || x > Field.maxHeigth {
                x = oldValue
            }
        }
    }
}


enum Direction {
    case up, down, right, left
}


struct Game {
    var player: Player
    var ball: Ball
    var gates: Gates
    var field: Field
    
    
    func goal() {
        if ball.x == gates.x && ball.y == gates.y {
            print("You Win, ball in the gates!")
            Grass = Firework
        }
    }
    
    mutating func run(move: Direction) {
        switch move {
        case .up: player.y += 1
            if player.y == ball.y && player.x == ball.x {
                ball.y += 1
                goal()
            }
        case .down: player.y -= 1
            if player.y == ball.y && player.x == ball.x {
                ball.y -= 1
                goal()
            }
        case .right: player.x += 1
            if player.x == ball.x && player.y == ball.y {
                ball.x += 1
                goal()
            }
        case .left: player.x -= 1
            if player.x == ball.x && player.y == ball.y {
                ball.x -= 1
                goal()
            }
        }
        }
    
    func printfield() {
        
        for i in (1...Field.maxWidth).reversed() {
            for j in 1...Field.maxHeigth {
                var str = String()
                switch (i,j) {
                case(player.y, player.x): str = FootPlayer
                case(ball.y, ball.x): str = FootBall
                case(gates.y, gates.x): str = FootGates
                default: str = Grass
                }
                print(str, terminator: "")
            }
            print("\n", terminator: "")
        }
        print()
    }

}


var game1 = Game(player: Player(x: 2, y: 2), ball: Ball(x: 3, y: 3), gates: Gates(x: 6, y: 6), field: Field(width: 10, heigth: 10))
game1.printfield()

game1.run(move: .right)
game1.printfield()

game1.run(move: .up)
game1.printfield()

game1.run(move: .up)
game1.printfield()

game1.run(move: .up)
game1.printfield()

game1.run(move: .left)
game1.printfield()

game1.run(move: .up)
game1.printfield()

game1.run(move: .right)
game1.printfield()

game1.run(move: .right)
game1.printfield()

game1.run(move: .right)
game1.printfield()

