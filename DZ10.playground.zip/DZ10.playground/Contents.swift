//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

// task 1
func heart() -> String {
    return "\u{2764}"
}

func world() -> String {
    return "\u{1f30F}"
}

func eyes() -> String {
    return "\u{1F440}"
}

func flight() -> String {
    return "\u{1F525}"
}

func okey() -> String {
    return "\u{2705}"
}


print(heart() + world() + eyes() + flight() + okey())



// task 2
func chess (letter: String, number: Int) -> String {
    let letter = letter.lowercased()
    let alphabet = ["a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8]
    var text : String
    
    if number > alphabet.count || alphabet[letter] == nil || number < 1 {
        text = "Data is incorrect"
    } else {
        text = (alphabet[letter]! % 2 == number % 2) ? "black" : "white"
    }
    return text
}

print(chess(letter: "a", number: 1))


// another variant
func chessDesk (letter: String, number: Int) -> String {
    let letter = letter.lowercased()
    let alphabet = ["a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8]
    var text : String

    switch (alphabet[letter], number) {
    case let (a,b) where a == nil : fallthrough
    case let (_, b) where b > alphabet.count : fallthrough
    case let (_, b) where b < 1 : text = "Date is incorrect"
    case let (a, b) where a! % 2 == b % 2 : text = "black"
    case let (a, b) where a! % 2 != b % 2: text = "white"
    default : text = "Date is incorrect"
    }

return text
}

print(chess(letter: "a", number: 2))


// task 3
let someArray1 = [1, 2, 3, 5, 4]
let someArray2 = ["a", "b", "c", "d", "e"]

func reversedArray(array: [Any]) -> [Any] {
    var reversed = [Any]()
    
    for i in array {
        reversed.insert(i, at: 0)
    }
    return reversed
}

var sArray1 = someArray1.sorted()
reversedArray(array: sArray1)
reversedArray(array: someArray2)


func reversedRange(ofAnyType range: Any...) -> [Any] {
    return reversedArray(array: range)
}

reversedRange(ofAnyType: 1, 2, 4, 3, 5)
reversedRange(ofAnyType: "a", "b", "c", "d", "e")



// task 4
var someArray: [Any] = [1, 2, 3, 4, 5, 7, 6, 9, 8]

func reversedAndSave(array: inout [Any]) {
    for i in array {
        array.insert(i, at: 0)
        array.removeLast()
    }
}

reversedAndSave(array: &someArray)
someArray



// task 5
let str  = "16 abcd, !@#$%<> 78293. Hello Servin. Why? Whant!"

func destroy(string: String) -> String {
    var destroyString =  ""
    let numbers = [" zero", " one", " two", " three", " four", " five", " six", " seven", " eight", " nine"]
    
    for i in string.lowercased() {
        switch i {
        case "a", "e", "o", "i", "y": destroyString += i.uppercased()
        case "b" ... "z": destroyString += i.lowercased()
        case "1", "2", "3", "4", "5", "6", "7", "8", "9": destroyString += numbers[Int(String(i))!]
        case " ": destroyString += " "
        default: destroyString += ""
        }
    }
    return destroyString
}

destroy(string: str)
print(destroy(string: str))


let number = 2221
var result: String?

let numbers = [1: "one", 2: "two"]
result = numbers[number]



func fact(number: Int) -> Int {
    if number <= 1 {
return 1
}

    return number * fact(number: number - 1)
}

fact(number: 10)
