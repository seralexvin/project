import UIKit

// task 2.1
/*
print("\(UInt8.min)")
print("\(UInt8.max)")

print("\(UInt16.min)")
print("\(UInt16.max)")

print("\(UInt32.min)")
print("\(UInt32.max)")

print("\(UInt64.min)")
print("\(UInt64.max)")


print("\(Int8.min)")
print("\(Int8.max)")

print("\(Int16.min)")
print("\(Int16.max)")

print("\(Int32.min)")
print("\(Int32.max)")

print("\(Int64.min)")
print("\(Int64.max)")

// task 2.2

let first = 10
let second: Float = 1.8
let third = 4.97

let firstSum = first + Int(second) + Int(third)
let secondSum = Float(first) + second + Float(third)
let thirdSum = Double(first) + Double(second) + third

// task 2.3

if first > Int(thirdSum) {
    print("\(firstSum) больше, чем \(thirdSum)")
} else if first < Int(thirdSum) {
    print("\(firstSum) меньше, чем \(thirdSum)")
} else {
    print("\(firstSum) равен \(thirdSum)")
}



// task 3.1

var student1 = (maxOtz: 10, maxPodt: 12, maxPrised: 25)
print(student1)

// task 3.2

print(student1.0)
print(student1.1)
print(student1.2)

print(student1.maxOtz)
print(student1.maxPodt)
print(student1.maxPrised)

// task 3.3

var student2 = (maxOtz: 20, maxPodt: 25, maxPrised: 100)

//var reverse = student2
//student1 = reverse
//
////student1

// task 3.4

var student3 = ((student2.maxOtz - student1.maxOtz), (student2.maxPodt - student1.maxPodt), (student2.maxPrised - student1.maxPrised))
print(student3)



// task 4.1

let str1 = "12"
let str2 = "145sa"
let str3 = "31"
let str4 = "11b"
let str5 = "7"


if Int(str1) != nil {
    let a = Int(str1)
}

if Int(str2) != nil {
    let a = Int(str2)
}

if Int(str3) != nil {
    let a = Int(str3)
}

if Int(str4) != nil {
    let a = Int(str4)
}

if Int(str5) != nil {
    let a = Int(str5)
}



if let a = Int(str1) {
    a
}

if let a = Int(str2) {
    a
}

if let a = Int(str3) {
    a
}

if let a = Int(str4) {
    a
}

if let a = Int(str5) {
    a
}

var array = [Int(str1), Int(str2), Int(str3), Int(str4), Int(str5)]

var sum = 0

for item in array {
    if let a = item {
        sum += a
    }
}
print("Сумма все строковых констант будет равна = \(sum)")


// task 4.2

var server = (statusCode: 200, message: "Absolut good", errorMessage: "WRONG!")

if server.statusCode >= 200  && server.statusCode < 300{
    print("\(server.message)")
} else {
    print("\(server.errorMessage)")
}


var server2 = (message: "Absolut good", errorMessage: "WRONG!")

if server2.message != nil {
    print("\(server.message)")
} else {
    print("\(server.errorMessage)")
}


// task 4.3

var student1: (name: String?, numOfCar: String?, grade: Int?)
var student2: (name: String?, numOfCar: String?, grade: Int?)
var student3: (name: String?, numOfCar: String?, grade: Int?)
var student4: (name: String?, numOfCar: String?, grade: Int?)
var student5: (name: String?, numOfCar: String?, grade: Int?)

student1.name = "Alex"
student2.name = "Vika"
student2.grade = 4
student3.name = "Pavel"
student3.numOfCar = "o777pp"
student3.grade = 5
student4.name = "Ksenia"
student4.numOfCar = "o111oo"
student4.grade = 4
student5.name = "Ivan"
student5.grade = 3

if let a = student1.numOfCar {
    print("The student have a car with number \(a)")
} else {
    print("not have")
}

if student1.grade != nil {
    print("Student grade = \(student1.grade!)") // аккуратно
} else {
    print("Student 1 not have a grade")
}

if let a = student1.numOfCar {
    print("The student have a car with number \(a)")
} else {
    print("Student 1 not have a car")
}

 

// task 5.1

let seconds = 60
let minuts = 60
let hours = 24

let myB = (day: 26, months: 8)
var secInDay = hours * minuts * seconds

var year = (jan: 31, feb: 28, mar: 31, apr: 30, may: 31, jun: 30, jyl: 31, aug: 31, sep: 30, oct: 31, nov: 30, dec: 31)

var daysOfB = (year.jan + year.feb + year.mar + year.apr + year.may + year.jun + year.jyl + myB.months)
var secOfB = secInDay * daysOfB


// task 5.2

var kv1 = year.jan + year.feb + year.mar
var kv2 = year.apr + year.may + year.jun
var kv3 = year.jyl + year.aug + year.sep
var kv4 = year.oct + year.nov + year.dec


if daysOfB < kv1 {
    print("I born in first quartal")
} else if daysOfB < kv2 + kv1 {
    print("I born in second quartal")
} else if daysOfB < kv3 + kv2 + kv1 {
    print("I born in third quartal")
} else if daysOfB < kv4 + kv3 + kv2 + kv1 {
    print("I born in fourth quartal")
}


// task 5.3

var a = 5
var b = 6
var c = 7
var d = 8
var e = 9
var f = 10



// task 5.4

var x = 5
var y: Character = "b"

var yNumber = 3

if y == "a" {
    yNumber = 1
} else if y == "b" {
        yNumber = 2
} else if y == "c" {
    yNumber = 3
} else if y == "d" {
    yNumber = 4
} else if y == "e" {
    yNumber = 5
} else if y == "f" {
    yNumber = 6
} else if y == "g" {
    yNumber = 7
} else if y == "h" {
    yNumber = 8
}

var color = (x + yNumber) % 2 == 0 ? "Black" : "White"


if x % 2 == 0 && yNumber % 2 == 0 {
    print("Black")
} else {
    print("White")
}




// task 6.1

let str1 = "12"
let str2 = "10a"
let str3 = "7"
let str4 = "7b"
let str5 = "11"

Int(str1)
Int(str2)
Int(str3)
Int(str4)
Int(str5)

var num1 = Int(str1) != nil ? Int(str1) : nil
var num2 = Int(str2) != nil ? Int(str2) : nil
var num3 = Int(str3) != nil ? Int(str3) : nil
var num4 = Int(str4) != nil ? Int(str4) : nil
var num5 = Int(str5) != nil ? Int(str5) : nil

var sumAll = ("\(num1) + \(num2) + \(num3) + \(num4) + \(num5)")


// task 6.2



// task 6.3

var str = "abcdefghijklmnopqrstuvwxyz"
let symbol: Character = "s"
var count = 0

for i in str {
    count += 1
    if i == symbol {
        print("\(i) = \(count)")
    }
}




// task 7.1

let daysArray = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

let mounthsArray = ["jan", "feb", "mar", "apr", "may", "jun", "jyl", "aug", "sep", "oct", "nov", "dec"]


for days in daysArray {
    print(days)
}
//
for mounts in 0..<mounthsArray.count {
    print("\(mounthsArray[mounts]) = \(daysArray[mounts])")
}
//
for days in 0..<daysArray.count{
    print("\(daysArray[days]) = \(mounthsArray[days])")
}
//
let tupleArray = ["jan": 31, "feb": 28, "mar": 31, "apr": 30, "may": 31, "jun": 30, "jyl": 31, "aug": 31, "sep": 30, "oct": 31, "nov": 30, "dec": 31]

for (key, value) in tupleArray {
    print("\(key) = \(value)")
}

for i in daysArray.reversed() {
    print(i)
}


let daysArray2 = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]


var myMonths = 8
var myDay = 26
var count = 0


for days in 0..<(myMonths - 1) {
    count += daysArray2[days]
}

var sum = count + myDay
print(sum)


// task 7.2

var array1 = [1, 10, nil, 9, nil]

var count = 0

for i in array1 {
    if i != nil {
        count += i!
    }
}
print(count)


count = 0

for i in array1 {
    if let a = i {
        count += a
    }
}
print(count)


count = 0

for i in array1 {
    let a = i ?? 0
    count += a
}
print(count)
 

// task 7.3

var str = "abcdefghijklmnopqrstuvwxyz"
var strVoid: [String] = []

for item in str {
    
    strVoid.insert(String(item), at: 0)
}

print(strVoid)




// task 8.3

let str1 = ["a", "b", "c", "d", "e", "f", "g", "h"]
var dict = [String : Bool]()

for i in 0..<str1.count {
    for j in 1...8 {
        if i % 2 == j % 2 {
            dict["\(str1[i]) \(j)"] = true
        } else {
            dict["\(str1[i]) \(j)"] = false
        }
    }
}

for (key, value) in dict {
    print("\(key) : \(value ? "White" : "Black")")
}



let puzzleInput = "Hello, my dear friend. How are you?"
var puzzleOutput = ""
let someCharacter: [Character] = ["a", "e", "y", " "]

for item in puzzleInput {
    if someCharacter.contains(item) {
        continue
    } else {
        puzzleOutput.append(item)
    }
}

print(puzzleOutput)




 */


/*
func animate(duration: Double, animations: () -> Void) {
    print("Starting a \(duration) second animations")
    animations()
}


//animate(duration: 3, animations: {
//    print("Image")
//})

animate(duration: 3) {
    print("Image")
}
 */





// task 9.1

/*
let str = "dsjcjhsdau378192><>,.,.,!)(@)09198/..>?<><?k;k;l42798928^&*&*&@(*#(*><?><><MM>NJSDBKHLJLKSN8098)*!@)jndkwjckj;ndjblksklsknflcjn;kjsdnkch439802i-03-92;,/.,/.182978675746T2*@&4jn;dl983781783979482r4knv'"

var strLowstr = str.lowercased()
var count = (vowels: 0, consonant: 0, number: 0, symbol: 0)


for word in strLowstr {
    
    switch word {
    case "a", "e", "i", "o", "u", "y": count.vowels += 1
    case "b"..."z": count.consonant += 1
    case "0"..."9": count.number += 1
    default: count.symbol += 1
    }
    
}

print(count)


// task 9.2

var life = 35

switch life {
case 1...6: print("child")
case 7...17: print("schollboy")
case 18...24: print("student")
case 25...35: print("man")
case 36...45: print("father")
default: print("Who are you?")
}


// task 9.3
/*
var student = (name: "Алекс", surname: "Иванов", patronymic: "Ветрович")


switch (student.name, student.surname, student.patronymic) {
    
case(_, _, _) where student.name.hasPrefix("А") || student.name.hasPrefix("О"): print("Hello \(student.name)")
case(_, _, _) where student.patronymic.hasPrefix("В") || student.patronymic.hasPrefix("Д"): print("Hello \(student.name) \(student.patronymic)")
case(_, _, _) where student.surname.hasPrefix("Е") || student.surname.hasPrefix("З"): print("Hello \(student.surname)")

default: print("Who are you?")
}
*/

// или так попроще

var student = (name: "Алекс", surname: "Иванов", patronymic: "Ветрович")


switch (student.name, student.surname, student.patronymic) {
    
case(let a, _, _) where a.hasPrefix("О"): print("Hello \(a)")
case(let a, _, let c)  where c.hasPrefix("Д"): print("Hello \(a) \(c)")
case(_, let b, _) where b.hasPrefix("З"): print("Hello \(b)")

default: print("Who are you?")
}


// task 9.4

var point1 = (x: 8, y: 9)


switch point1 {
case(let a, let b) where a == 5 && b == 7: print("ubil")
case(let a, let b) where a == 5 || b == 7: print("ranil")
default: print("mimo")
}





// task 10.1

func smile() -> String {
    return("\u{1f602}")
}

func heart() -> String {
    return("\u{2665}")
}

func love() -> String {
    return("\u{1f970}")
}

print("\(smile())"  +  "\(heart())" + "\(love())")



// task 10.2
let letters: [Character] = ["a", "b", "c", "d", "e", "f", "j", "h"]

func chessDesk(number: Int, word: Character) -> String? {
    
    var result: String? = nil
    var letterIndex = 1
    
    
    for i in letters {
        if i == word {
            result = (letterIndex % 2) == (number % 2) ? "Black" : "White"
        }
        letterIndex += 1
    }
    
    return result
   
}

chessDesk(number: 10, word: "a")



// task 10.1

let letters: [Character] = ["a", "b", "c", "d", "e", "f", "j", "h"]

//func chessDesk(word: Character, symbol: Int) -> String? {
//    var str: String? = nil
//    var letterIndex = 1
//
//    for i in letters {
//        if i == word {
//            str = (letterIndex % 2) == (symbol % 2) ? "Black" : "White"
//        }
//        letterIndex += 1
//    }
//    return str
//}
//
//chessDesk(word: "a", symbol: 1)

func chessDesk(word: Character, symbol: Int) -> String? {
    var str: String? = nil
    var symbolLetter = 1
    
    for i in letters {
        if i == word {
            str = (symbolLetter % 2) == (symbol % 2) ? "Black": "White"
        }
        symbolLetter += 1
    }
    return str

}

chessDesk(word: "a", symbol: 8)



// task 10.2

func massiv(array: [Int]) -> [Int?] {
    var massivReverse: [Int?] = []
    
    for item in array {
        massivReverse.insert(item, at: 0)
    }
    
    
    return massivReverse
}

var array1 = [4, 2, 6, 5, 9, 0, 1, 7, 8, 3]

var sort = massiv(array: array1)


// task 10.3

func massiv2(index myIndex: Int...) -> [Int?] {
    return massiv(array: myIndex)
}

massiv2(index: 30, 20, 34, 60, 73, 85, 63)


func massiv3(item myItem: Int...) -> [Int?] {
        return massiv(array: myItem)
}

var result = massiv3(item: 50, 30, 40, 50, 10, 0)



// task 10.4

func myArray(array: inout [Int]) {
    
    for item in array {
        array.insert(item, at: 0)
        array.removeLast()
    }
}

var myIndex = [10, 9, 8, 7, 6]
myArray(array: &myIndex)


// task 10.5

func action(str: inout String) -> String {
    let numStr = ["0": "zero", "1": "one", "2": "two", "3": "three", "4": "four", "5": "five", "6": "six", "7": "seven", "8": "eight", "9": "nine"]
    
    str = str.lowercased()
    var returnStr = ""

    
    for element in str {
        switch element {
        case ".", ",", "!", "?", "@", "#", "$", "%", "*", "(", ")", "-", "+", "&": break
        case "a", "e", "y", "u", "i", "o": returnStr += String(element).uppercased()
        case let char where (numStr[String(char)] != nil): returnStr += numStr[String(char)]!
        default: returnStr += String(element)
        }
    }
    str = returnStr
    return returnStr
}


var fun = "1(*!&@(*#(IY*&@*)OWJ1083737234IUFHECdjksaU"
print(action(str: &fun))

 */




/*

func travel (action: (String) -> Void) {
    print("I'm getting rady to go")
    action("London")
    print("I arrived!")
}


travel { (place: String) in
    print("I'm going to \(place) in my car")
}



let changeSpeed = { (speed: Int) in
    print("Changing speed to \(speed) kph")
    
}

func buildCar(name: String, engine: (Int) -> Void) {
    
}



func travel2(action: (String) -> String) {
    print("I'm getting rady to go")
    let description = action("London")
    print(description)
    print("I arrieved!")
}

print("\n")
travel2 { (place: String) -> String in
    return "I'm going \(place) in my car"
}

print("\n")
travel2 { place in
    "I'm going \(place) in my car"
}

print("\n")
travel2 {
    "I'm going \($0) in my car"
}


func travel3(action: (String, Int) -> String) {
    print("I'm getting rady to go")
    let desc = action("London", 60)
    print(desc)
    print("I arrieved!")
}

print("\n")
travel3 {
    "I'm going to \($0) with \($1) speed"
}



func travel4() -> (String) -> Void {
    var counter = 1
    return {
        print("\(counter). I'm going to \($0)")
        counter += 1
    }
}


print("\n")
let result = travel4()
result("London")
result("London")
result("London")
result("London")






// task 11.1

func action(runtime: () -> ()) {

    for i in 1...10 {
        print(i)
    }
    
    runtime()
    print(runtime())
}

action{}



// task 11.2

var array = [1, 6, 3, 8, 5, 0, 9, 7, 2, 4]

func sortVozr(_ s1: Int, _ s2: Int) -> Bool {
    return s1 < s2
}

var sorted1 = array.sorted(by: sortVozr)


func sortUbiv(_ s1: Int, _ s2: Int) -> Bool {
    return s1 > s2
}

var sorted2 = array.sorted(by: sortUbiv)



// task 11.3

func myFunc(array: [Int], closure: (Int, Int?) -> Bool) -> Int {
    
    var number: Int?
    
    for item in array {
        if closure(item, number) {
            number = item
        }
    }
   
    return number ?? 0
}

var myArray2 = [1, 3, 6, 4, 7]

let minimum = myFunc(array: myArray2, closure: { if let number = $1 {
    return $0 < number
}
return true
})

let maximum = myFunc(array: myArray2) { $0 > $1 ?? 0}
print(maximum)

let maximum2 = myFunc(array: myArray2, closure: { if let a = $1 {
    return $0 < a
}
return true
})



// task 11.4

var str = "Hello my dear friend. 12345, !.(8&&#^@*&*!"
var strArray = [String]()

for char in str {
    strArray.append(String(char))
}


func strSort(array: String) -> Int {
    switch array.lowercased() {
        case "a", "e", "i", "o", "u", "y": return 0
        case "b"..."z": return 1
        case "0"..."9": return 2
        default: return 3
        }
    }
    
let sortArray = strArray.sorted() {
    switch (strSort(array: $0), strSort(array: $1)) {
        case let (x, y) where x < y: return true
        case let (x, y) where x > y: return false
        default: return $0.lowercased() <= $1.lowercased()
    }
}


print(sortArray)



// task 11.5

let max = myFunc(array: myArray2) {$1 == nil || $0 > $1!}
print(max)

let min = myFunc(array: myArray2) {$1 == nil || $0 < $1!}
print(min)

 */




// task 13.1

struct Student {
    var name: String
    var surname: String
    var year: Int
    var point: Double
}


var student1 = Student(name: "Alex", surname: "Ivanov", year: 1995, point: 4.5)
var student2 = Student(name: "Victor", surname: "Ivanov", year: 1997, point: 4.0)
var student3 = Student(name: "Vasiliy", surname: "Pupkin", year: 1999, point: 3.5)
var student4 = Student(name: "Vika", surname: "Oper", year: 2000, point: 5.0)
var student5 = Student(name: "Katya", surname: "Boom", year: 2002, point: 5.0)

var journal = [student1, student2, student3, student4, student5]


// task 13.2

func myJournal(array: [Student]) {
    var counter = 1
    
    for element in array {
        print("\(counter). The student - \(element)")
        counter += 1
    }
}

print(myJournal(array: journal))



// task 13.3

var sort = journal.sorted(by: {$0.point > $1.point})
print(myJournal(array: sort))



// task 13.4

var sort2 = journal.sorted(by: { if $0.surname == $1.surname {
    return $0.name < $1.name
}
return true
})
print(myJournal(array: sort2))


// task 13.5

var result = journal
result[0].name = "Bob"
result[1].surname = "Fincher"
result[2].year = 1950
result[3].point = 1.5


print(myJournal(array: journal))
print(myJournal(array: result))


// task 13.6

class Student2 {
    var name: String
    var surname: String
    var year: Int
    var point: Double
    
    init(name: String, surname: String, year: Int, point: Double) {
        self.name = name
        self.surname = surname
        self.year = year
        self.point = point
    }
}

var studentCl1 = Student2(name: "Alex", surname: "Ivanov", year: 1990, point: 4.5)
var studentCl2 = Student2(name: "Victor", surname: "Ivanov", year: 1991, point: 4.0)
var studentCl3 = Student2(name: "Pavel", surname: "Vinokur", year: 1992, point: 3.5)
var studentCl4 = Student2(name: "Vika", surname: "Palmer", year: 1993, point: 5.0)
var studentCl5 = Student2(name: "Katya", surname: "Boomer", year: 1994, point: 5.0)


var journalCl = [studentCl1, studentCl2, studentCl3, studentCl4, studentCl5]


func myJournalCl(array: [Student2]) {
    var counter = 1
    
    for element in array {
        print("\(counter). The student - \(element.name)\t \(element.surname) \t\(element.year) \t\(element.point)")
        counter += 1
    }
}

myJournalCl(array: journalCl)

print("n")
var sortPoint = journalCl.sorted(by: {$0.point > $1.point})
print(myJournalCl(array: sortPoint))


var sortSurname = journalCl.sorted(by: { if $0.surname == $1.surname {
    return $0.name < $1.name
}
return true
})

print(myJournalCl(array: sortSurname))



var remain = journalCl
remain[0].name = "Bob"
remain[1].surname = "Singer"
remain[2].point = 1.0
remain[3].year = 2000

print(myJournalCl(array: journalCl))
print("\n")
print(myJournalCl(array: remain))





// task 13.7

enum Chess: Int {
    case King
    case Queen
    case Rook
    case Bishop
    case Knight
    case Pawn
}


enum Type {
    case White
    case Black
}


func toString(type: Type, piece: Chess) -> String {
    let numbersOfPieces = 6
    let delta = type == .White ? 0 : numbersOfPieces
    let unicode = 0x2654 + piece.rawValue + delta
    let scalar = UnicodeScalarType(unicode)
    
    return String(scalar)
    
}

toString(type: .White, piece: .Rook)
