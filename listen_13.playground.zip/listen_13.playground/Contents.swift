import UIKit


var russianCurrency: String = "Rouble"

var currency: [String] = ["Rouble", "Dollar", "Euro"]
var russian = currency[0]


enum Currency {
    case rouble(country: [String], shortName: String)
    case dollar(country: [String], shortName: String, national: DollarCountries)
    case euro(country: [String], shortName: String)
}

var russia: Currency
russia = .rouble(country: ["Russia"], shortName: "rub")


enum DollarCountries {
    case usa
    case canada
    case australia
}


var dollar: Currency
dollar = .dollar(country: ["USA"], shortName: "USD", national: .usa)





var somePiece = Currency.rouble(country: ["Россия", "Ukraine", "Belarus"], shortName: "RUB")
var somePiece2 = Currency.dollar(country: ["Amerika, Kanada, Australia"], shortName: "USA", national: .usa)

switch somePiece2 {
case .rouble: print("Rouble")
case let .euro(country, shortname): print("Еврою. СТраны: \(country), краткое наименование: \(shortname)")
case .dollar(let country, let shortName, let national): print("Доллар \(national). Страны: \(String(describing: country)), краткое наименование: \(shortName)")
}





enum Currency1 {
    case rouble, dollar, euro
}


var russian1 = Currency1.rouble

let russian2: Currency1
russian2 = .rouble






enum Chessmen {
    
    enum Color {
        case white
        case black
    }
    
    case king(name: String, color: Color)
    case queen(name: String, color: Color)
    case bishop(name: String, color: Color)
    case knight(name: String, color: Color)
    case rook(name: String, color: Color)
    case pawns(name: String, color: Color)
  
}

var piece5 = Chessmen.king(name: "Король", color: .white)
var piece6 = Chessmen.knight(name: "Конь", color: .black)

let piece7: Chessmen
piece7 = .pawns(name: "Пешка", color: .white)

let piece1: Chessmen
piece1 = .king(name: "Король", color: .white)

let piece2: Chessmen
piece2 = .knight(name: "Конь", color: .black)

let piece3 = Chessmen.queen
let piece4 = Chessmen.bishop





enum Smile: String {
    case joy = ":)"
    case laugh = "xD"
    case sorrow = ":("
    case surpeice = "o_O"
    
    var desription: String {return self.rawValue}
}

var desc: Smile = .joy
desc.desription

var des2: Smile = .surpeice
des2.desription








enum Planet: Int {
    case mercury = 1, venus, earth, mars, jupiter, saturn, uranus, neptune, pluton = 999
}


enum Color1: String {
    case white = "белый"
    case black = "черный"
}

var colorIst: Chessmen
colorIst = .king(name: "Король", color: .black)

switch colorIst {
case .king(let name, let color): print("для фигуры \(name) с цветом \(color) связанное значение = \(Color1.black.rawValue)")
default: break
}




var coloIst2: Chessmen
coloIst2 = .bishop(name: "Слон", color: .white)

switch coloIst2 {
case .bishop(let name, let color): print("Для фигуры \(name) с цветом \(color) связанное значение = \(Color1.white.rawValue)")
default: break
}





enum Smile1: String {
    case joy = ":)"
    case laugh = "xD"
    case sorrow = ":("
    case surpeice = "o_O"
    
    func description() {
        print("перечисление содержит ...")
    }
    
    func descreiptionValue() -> Smile1 {
        return self
    }
    
    func desriptionRawValue() -> String {
        return self.rawValue
    }
    
}

var desc2: Smile1 = .joy
desc2.description()

desc2.descreiptionValue()
desc2.desriptionRawValue()








enum ArithmeticExpression {
    case adition(Int, Int)
    case substraction(Int, Int)
    case multiplication(Int, Int)
    case division(Int, Int)
    
    func calculate() -> Int {
        switch self {
        case .adition(let one, let two): return one + two
        case .substraction(let one, let two): return one - two
        case .multiplication(let one, let two): return one * two
        case .division(let one, let two): return one / two
        }
    }
}

var result = ArithmeticExpression.adition(10, 15)
var result2 = ArithmeticExpression.substraction(15, 10)
var result3 = ArithmeticExpression.multiplication(10, 2)
var result4 = ArithmeticExpression.division(25, 5)

result.calculate()
result2.calculate()
result3.calculate()
result4.calculate()






enum Arithmetic {
    case number(Int)
    indirect case adition(Arithmetic, Arithmetic)
    indirect case substraction(Arithmetic, Arithmetic)
    indirect case multiplication(Arithmetic, Arithmetic)
    indirect case division(Arithmetic, Arithmetic)
    indirect case exponentiation(Arithmetic, Arithmetic)
    
    func calculate(expression: Arithmetic? = nil) -> Int {
        let expression = (expression == nil ? self : expression)
        
        switch expression! {
        case .number(let value): return value
        case .adition(let valueOne, let valueTwo): return self.calculate(expression: valueOne) + self.calculate(expression: valueTwo)
        case .substraction(let valueOne, let valueTwo): return self.calculate(expression: valueOne) - self.calculate(expression: valueTwo)
        case .multiplication(let valueOne, let valueTwo): return self.calculate(expression: valueOne) * self.calculate(expression: valueTwo)
        case .division(let valueOne, let valueTwo): return self.calculate(expression: valueOne) / self.calculate(expression: valueTwo)
        case .exponentiation(let valueOne, let valueTwo): return self.calculate(expression: valueOne) * self.calculate(expression: valueTwo) * self.calculate(expression: valueTwo)
            
        }
        }
    }
    
var expr = Arithmetic.exponentiation(.number(10), .number(2))
expr.calculate()







struct Color10 {
    let color1: String = "White"
    let color2: String = "Black"
}


var colorNum = Color10()
print(colorNum)
colorNum.color1
colorNum.color2



struct ChessFigure {
    let king: String = "King"
    let queen: String = "Queen"
    let bishop: String = "Bishop"
    let knight: String = "Knight"
    let rook: String = "Rook"
    let pawns: String = "Pawns"
}


struct Chessman {
    var type: ChessFigure
    var colorType: Color10
    var coordinates: ((String, Int)?)
    
    init(coordinates: (String, Int)?, type: ChessFigure, colorType: Color10) {
        self.coordinates = coordinates
        self.type = type
        self.colorType = colorType
        
    }
    
}
