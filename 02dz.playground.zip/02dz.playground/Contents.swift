//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

let a = 5
let b : Float = 4.8
let c = 3.7

let sum1 = Int(Double(a) + Double(b) + c)
let sum2 = Float(a) + b + Float(c)
let sum3 = Double(a) + Double(b) + c

if Double(sum1) < sum3 {
    print("Double is greater")
} else {
    print("Int is greater or equal")
}
