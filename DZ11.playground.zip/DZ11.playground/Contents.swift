//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport


// task 1

func first(closure: () -> ()) {
    
    var sum = 0
    for i in 1...10 {
        sum += 1
        print(i)
    }
    
    print("sum is \(sum)")
closure()

}

first {
    print("closure")
}



// task 2

let array = [20, 21, 4, 3, 1, 9, 10, 7, 9]

print(array.sorted(by: >))
print(array.sorted(by: <))

// task 3

func second(array: [Int], closure1: (Int?, Int) -> Bool) -> Int {
    var number : Int?
    
    for value in array {
        if closure1(number, value) {
            number = value
        }
    }
    return number!
}

let numbers = [1, 2, 6, 4, 5, 3, 8, 0]

let any = second(numbers) {
    in $0 == nil || $0! == $1
}

