//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

// TASK 1
let a = "123"
let b = "a8b7c8"
let c = "64"
let d = "1"
let e = "zxcv"


// 1 metod forced
var sum = 0

if Int(a) != nil {
    sum = sum + Int(a)!
}

if Int(b) != nil {
    sum = sum + Int(b)!
}

if Int(c) != nil {
    sum = sum + Int(c)!
}

if Int(d) != nil {
    sum = sum + Int(d)!
}

if Int(e) != nil {
    sum = sum + Int(e)!
}


// 2 metod optional binding
var sum1 = 0
if let sum = Int(a) {
    sum1 += Int(a)!
}
 
if let sum = Int(b) {
    sum1 += Int(b)!
}

if let sum = Int(c) {
    sum1 += Int(c)!
}

if let sum = Int(d) {
    sum1 += Int(d)!
}

if let sum = Int(e) {
    sum1 += Int(e)!
}



// TASK 2
var serverHost : (statusCode: Int, message: String?, errorMesage: String?) = (200, "It is OK!", "oops, not connection")

if serverHost.statusCode >= 200 && serverHost.statusCode < 300 {
    print("The status code is \(serverHost.statusCode) - \(serverHost.message!)")
} else {
    print("The status code is \(serverHost.errorMesage!)")
}


if let actualHost = serverHost.message {
    print(serverHost.message!)
} else {
    print(serverHost.errorMesage!)
}


// TASK 3
var student1 : (name: String?, numberOfCar: Int?, result: Int?)
var student2 : (name: String?, numberOfCar: Int?, result: Int?)
var student3 : (name: String?, numberOfCar: Int?, result: Int?)
var student4 : (name: String?, numberOfCar: Int?, result: Int?)
var student5 : (name: String?, numberOfCar: Int?, result: Int?)

student1.name = "Ivan"
student2.name = "Nika"
student3.name = "Petr"
student4.name = "Vika"
student5.name = "Sveta"

student1.numberOfCar = 961
student2.numberOfCar = 111
student4.numberOfCar = 777

student1.result = 3
student2.result = 5
student3.result = 5
student4.result = 4


print("The first student's name is \(student1.name!)")
print("The second student's name is \(student1.name!)")
print("The third student's name is \(student1.name!)")
print("The fourth student's name is \(student1.name!)")
print("The fifth student's name is \(student1.name!)")


if student1.numberOfCar != nil {
    print("The student 1 number of car - \(student1.numberOfCar!)")
} else {
    print("The student 1 not have a car")
}

if student2.numberOfCar != nil {
    print("The student 2 number of car - \(student2.numberOfCar!)")
} else {
    print("The student 2 not have a car")
}

if student3.numberOfCar != nil && student3.result != nil {
    print("The student 3 number of car - \(student3.numberOfCar!)")
} else {
    print("The student 3 not have a car")
}

if student4.numberOfCar != nil {
    print("The student 4 number of car - \(student4.numberOfCar!)")
} else {
    print("The student 4 not have a car")
}

if student5.numberOfCar != nil {
    print("The student 5 number of car - \(student5.numberOfCar!)")
} else {
    print("The student 5 not have a car")
}


if student1.result != nil {
    print("The student 1 got a grade - \(student1.result!)")
} else {
    print("The student 1 not a got grade!")
}

if student2.result != nil {
    print("The student 2 got a grade - \(student2.result!)")
} else {
    print("The student 2 not a got grade!")
}

if student3.result != nil {
    print("The student 3 got a grade - \(student3.result!)")
} else {
    print("The student 3 not a got grade!")
}

if student4.result != nil {
    print("The student 4 got a grade - \(student4.result!)")
} else {
    print("The student 4 not a got grade!")
}

if student5.result != nil {
    print("The student 5 got a grade - \(student5.result!)")
} else {
    print("The student 5 not a got grade!")
}

